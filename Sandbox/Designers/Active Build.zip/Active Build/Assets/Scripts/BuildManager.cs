﻿using UnityEngine;
using System.Collections;

public class BuildManager : MonoBehaviour 
{

	//This variable contained the current object that we can place down / deploy.
	public GameObject currentObject;

}
