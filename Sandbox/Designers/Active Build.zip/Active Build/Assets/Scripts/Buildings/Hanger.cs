﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Hanger : MonoBehaviour 
{

	public Sprite icon;
	public string description;

	// Use this for initialization
	void Start () 
	{

	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
